for (let line = "#"; line.length < 8; line += "#")
  console.log(line);
